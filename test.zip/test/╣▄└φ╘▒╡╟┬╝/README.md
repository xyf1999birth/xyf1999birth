登陆与注册页面 ajax请求  get 和post
