$(document).ready(function() {
  var panelOne = $('.form-panel.two').height(),
    panelTwo = $('.form-panel.two')[0].scrollHeight;

  $('.form-panel.two').not('.form-panel.two.active').on('click', function(e) {
    e.preventDefault();

    $('.form-toggle').addClass('visible');
    $('.form-panel.one').addClass('hidden');
    $('.form-panel.two').addClass('active');
    $('.form').animate({
      'height': panelTwo
    }, 200);
  });

  $('.form-toggle').on('click', function(e) {
    e.preventDefault();
    $(this).removeClass('visible');
    $('.form-panel.one').removeClass('hidden');
    $('.form-panel.two').removeClass('active');
    $('.form').animate({
      'height': panelOne
    }, 200);
  });
});

exports.index =function(req,res){
  var username=req.body.uname;
  var pwd=req.body.psd;
  var sql="select * from student where username=? and password=?";
 var con=dbcon.getCon();
  con.query(sql,[username,pwd], function (err,result) {
        if(!err){
            if(result.length==0){
                res.json(0);
            }else{
                res.json(1)
            }
        }else{
           console.log(err)
        }
      con.destroy()
  })
};//登录

exports.regists=function(req,res,name,password){
  var sql="insert into stuinfo(name,password) values(?,?)"
  conn.query(sql,[name,password],function(err,result){
      if(result.affectedRows==1){
          req.session.name=name;
          res.sendfile('./public/view.html')
      }
  })
}
exports.index=index;
//注册